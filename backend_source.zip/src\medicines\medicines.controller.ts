// backend/src/medicines/medicines.controller.ts
import { Controller, Get, Query } from '@nestjs/common';
import { MedicinesService } from './medicines.service';

@Controller('medicines')
export class MedicinesController {
  constructor(private readonly medicinesService: MedicinesService) {}

  @Get('search')
  async search(@Query('query') query: string) {
    const q = (query || '').trim();
    if (!q) return [];
    return this.medicinesService.searchMedicines(q);
  }
}
