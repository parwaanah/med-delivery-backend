// src/queues/queue.module.ts
import { Module, forwardRef } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { Queue } from 'bullmq';

import { OrderAssignWorker } from './order-assign.worker';

// Required services
import { PrismaService } from '../utils/prisma.service';
import { NotificationService } from '../utils/notification.service';
import { EscalationService } from '../admin/escalation.service';

import { WsModule } from '../ws/ws.module';
import { OrdersModule } from '../orders/orders.module';
import { AdminModule } from '../admin/admin.module';

import { GeoSurgeModule } from '../geosurge/geo-surge.module';
import { SurgeModule } from '../surge/surge.module';  // <-- 🔥 REQUIRED FIX

const REDIS_URL = 'redis://redis:6379';

@Module({
  imports: [
    forwardRef(() => OrdersModule),
    forwardRef(() => AdminModule),
    WsModule,

    // 🔥 FIX 1: Needed for GeoSurgeService
    GeoSurgeModule,

    // 🔥 FIX 2: Needed for SurgeService
    SurgeModule,

    // BullMQ global redis connection
    BullModule.forRoot({
      connection: {
        url: REDIS_URL,
      },
    }),

    // Register queue
    BullModule.registerQueue({
      name: 'order_assign',
    }),
  ],

  providers: [
    OrderAssignWorker,
    PrismaService,
    NotificationService,
    EscalationService,

    {
      provide: 'ORDER_ASSIGN_QUEUE',
      useFactory: () => {
        return new Queue('order_assign', {
          connection: { url: REDIS_URL },
        });
      },
    },
  ],

  exports: ['ORDER_ASSIGN_QUEUE', OrderAssignWorker],
})
export class QueueModule {}
