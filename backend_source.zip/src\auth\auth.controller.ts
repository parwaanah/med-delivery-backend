import {
  Body,
  Controller,
  Post,
  Get,
  Req,
  UseGuards,
} from '@nestjs/common';
import { Request } from 'express';
import { AuthGuard } from '@nestjs/passport';

import { AuthService } from './auth.service';
import {
  LoginDto,
  RegisterDto,
  RefreshTokenDto,
  SendOtpDto,
  VerifyOtpDto,
} from './dto/auth.dto';

@Controller('auth')
export class AuthController {
  constructor(private auth: AuthService) {}

  @Post('register')
  register(@Body() dto: RegisterDto) {
    return this.auth.register(dto);
  }

  @Post('login')
  login(@Req() req: Request, @Body() dto: LoginDto) {
    const ip = req.ip || '';
    const ua = String(req.headers['user-agent'] || '');
    return this.auth.login(dto, ip, ua);
  }

  @Post('refresh')
  refresh(@Body() dto: RefreshTokenDto) {
    return this.auth.refreshToken(dto.refreshToken);
  }

  @Post('logout')
  logout(@Body('sessionId') sessionId: number) {
    return this.auth.logout(sessionId);
  }

  // === OTP AUTH ===
  @Post('send-otp')
  sendOtp(@Body() dto: SendOtpDto) {
    return this.auth.sendOtp(dto);
  }

  @Post('verify-otp')
  verifyOtp(@Req() req: Request, @Body() dto: VerifyOtpDto) {
    const ip = req.ip || '';
    const ua = String(req.headers['user-agent'] || '');
    return this.auth.verifyOtp(dto, ip, ua);
  }

  // === GOOGLE LOGIN ===
  @Get('google')
  @UseGuards(AuthGuard('google'))
  googleAuth() {}

  @Get('google/callback')
  @UseGuards(AuthGuard('google'))
  googleCallback(@Req() req: any) {
    return this.auth.googleLogin(req.user);
  }
}
