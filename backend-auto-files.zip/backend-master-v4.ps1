# backend-master-v4.ps1
# Updated, fixed and Docker-first Redis startup with WSL fallback.
# Place at C:\Users\OMEN\med-delivery\backend\backend-master-v4.ps1

param()

$ErrorActionPreference = "Stop"

$backendDir   = "C:\Users\OMEN\med-delivery\backend"
$logFile      = Join-Path $backendDir "backend-master.log"
$dbUser       = "postgres"
$dbPass       = "Hello@123"
$dbHost       = "127.0.0.1"
$dbName       = "med_delivery"
$backendPort  = 3001

Add-Type -AssemblyName System.Windows.Forms
function Notify { param($title, $text)
    $n = New-Object System.Windows.Forms.NotifyIcon
    $n.Icon = [System.Drawing.SystemIcons]::Information
    $n.BalloonTipTitle = $title
    $n.BalloonTipText  = $text
    $n.Visible = $true
    $n.ShowBalloonTip(3000)
    Start-Sleep -Milliseconds 3500
    $n.Dispose()
}

function Log { param($msg, $color = "White")
    $time = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $line = "[$time] $msg"
    Write-Host $line -ForegroundColor $color
    Add-Content -Path $logFile -Value $line -ErrorAction SilentlyContinue
}

# start
if (Test-Path $logFile) { Remove-Item $logFile -Force -ErrorAction SilentlyContinue }
Log "Starting Backend Master Controller..."
Notify "Backend Controller" "Starting system checks..."
Set-Location $backendDir

# cleanup old auto scripts
Get-ChildItem -Path $backendDir -Filter "auto-*.ps1" -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -ne (Join-Path $backendDir "backend-master-v4.ps1") } |
    ForEach-Object { Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue }
Log "Old automation scripts cleaned." "Yellow"

# stop node
Get-Process -Name "node" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Log "Stopped any existing backend Node.js processes." "Yellow"

# PostgreSQL
try {
    $svc = Get-Service -Name "postgresql-x64-18" -ErrorAction SilentlyContinue
    if (-not $svc) { Log "PostgreSQL service missing." "Red" }
    elseif ($svc.Status -ne "Running") {
        Log "Starting PostgreSQL..." "Yellow"
        net start postgresql-x64-18 | Out-Null
    }
    Log "PostgreSQL service state: $($svc.Status)" "Green"
} catch { Log "PostgreSQL error: $($_.Exception.Message)" "Red" }

# Docker Redis start (preferred)
function Start-Redis-Docker {
    try {
        Log "Trying Docker Redis (docker compose)..." "Cyan"
        cd $backendDir
        # ensure no conflicting container names
        try { docker rm -f med_delivery_redis -v 2>$null } catch {}
        docker compose pull 2>&1 | Out-Null
        $up = docker compose up -d 2>&1
        if ($LASTEXITCODE -eq 0) {
            Start-Sleep -Seconds 2
            # healthcheck ping
            $ping = docker exec -i med_delivery_redis redis-cli ping 2>$null
            if ($ping -and $ping -match "PONG") {
                Log "Docker Redis started and responding (PONG)." "Green"
                return $true
            } else {
                Log "Docker Redis started but PING failed." "Yellow"
            }
        } else {
            Log "docker compose up failed: $up" "Yellow"
        }
    } catch {
        Log "Docker Redis error: $($_.Exception.Message)" "Yellow"
    }
    return $false
}

# WSL fallback (if Docker unavailable)
function Start-Redis-WSL {
    try {
        $check = & wsl --exec bash -lc "ss -tuln | grep ':6379' || true"
        if ($check -match '0\.0\.0\.0:6379' -or $check -match '127\.0\.0\.1:6379') {
            Log "Redis already active in WSL." "Green"
            return $true
        }
        Log "Starting Redis in WSL..." "Cyan"
        & wsl --exec bash -lc "sudo redis-server /etc/redis/redis.conf --daemonize yes" | Out-Null
        Start-Sleep -Seconds 2
        $verify = & wsl --exec bash -lc "ss -tuln | grep ':6379' || true"
        if ($verify -match '0\.0\.0\.0:6379' -or $verify -match '127\.0\.0\.1:6379') {
            Log "Redis started successfully in WSL." "Green"
            return $true
        }
        else { Log "Redis failed to start in WSL." "Yellow"; return $false }
    } catch {
        Log "Redis start error: $($_.Exception.Message)" "Yellow"
        return $false
    }
}

$redisStarted = Start-Redis-Docker
if (-not $redisStarted) {
    Log "Docker Redis not available — attempting WSL Redis fallback." "Yellow"
    $redisStarted = Start-Redis-WSL
}
if (-not $redisStarted) { Log "⚠️ Redis not detected. Some features (surge, queues) may be degraded." "Yellow" }

# Update .env DATABASE_URL (safe edit)
$envPath = Join-Path $backendDir ".env"
try {
    if (Test-Path $envPath) {
        $envText = Get-Content $envPath -Raw
        $newDbUrl = "DATABASE_URL=postgresql://${dbUser}:${dbPass}@${dbHost}:5432/${dbName}?schema=public"
        if ($envText -match "DATABASE_URL=") { $envText = $envText -replace "DATABASE_URL=.*", $newDbUrl }
        else { $envText += "`n$newDbUrl" }
        Set-Content -Path $envPath -Value $envText -Encoding UTF8
        Log "Updated .env DATABASE_URL to ${dbHost}" "Green"
    } else {
        Log ".env file not found; skipping .env update." "Yellow"
    }
} catch { Log ".env update failed: $($_.Exception.Message)" "Yellow" }

# pgpass setup (optional)
try {
    $pgpass = Join-Path $env:USERPROFILE ".pgpass"
    $pgpassLine = "${dbHost}:5432:${dbName}:${dbUser}:${dbPass}"
    Set-Content -Path $pgpass -Value $pgpassLine -Encoding ASCII
    icacls $pgpass /inheritance:r /grant:r "$($env:USERNAME):(R,W)" | Out-Null
    Log "Configured pgpass for psql." "Green"
} catch { Log "pgpass setup failed: $($_.Exception.Message)" "Yellow" }

# Prisma generate (retry loop)
function Prisma-Generate {
    for ($i = 1; $i -le 3; $i++) {
        try {
            Log "Running npx prisma generate (try $i)..." "Cyan"
            npx prisma generate 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) { Log "Prisma client ready." "Green"; return }
        } catch {
            Log "Prisma failed: $($_.Exception.Message)" "Yellow"
            Get-Process -Name "node" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
            Remove-Item -Recurse -Force "$backendDir\node_modules\.prisma" -ErrorAction SilentlyContinue
        }
        Start-Sleep -Seconds 2
    }
    Log "Prisma generate attempts exhausted." "Yellow"
}
Prisma-Generate

# Build backend
try {
    Log "Building Nest backend..." "Cyan"
    npm run build | Out-Null
    Log "Build complete." "Green"
} catch { Log "Build error: $($_.Exception.Message)" "Red" }

# Start backend inline (dev mode recommended)
Log "Starting backend (npm run start:dev) ..." "Cyan"
try {
    Set-Location $backendDir
    Start-Process -FilePath "cmd.exe" -ArgumentList "/c cd /d `"$backendDir`" && npm run start:dev" -WorkingDirectory $backendDir -WindowStyle Hidden
    Log "Backend process kicked off (background)." "Green"
} catch {
    Log "Error starting backend: $($_.Exception.Message)" "Red"
}

# Wait for swagger
for ($i = 0; $i -lt 60; $i++) {
    try {
        $r = Invoke-WebRequest -Uri "http://localhost:$backendPort/docs" -UseBasicParsing -TimeoutSec 2 -ErrorAction Stop
        if ($r.StatusCode -eq 200) {
            Log "Backend is LIVE at http://localhost:$backendPort/docs" "Green"
            Notify "Backend Ready" "Swagger Docs available now."
            break
        }
    } catch { Start-Sleep -Seconds 1 }
}

# monitor job (keeps redis & pg & node running)
$monitorScript = {
    param($backendDir, $backendPort)
    while ($true) {
        try {
            $pg = Get-Service -Name "postgresql-x64-18" -ErrorAction SilentlyContinue
            if ($pg -and $pg.Status -ne "Running") { net start postgresql-x64-18 | Out-Null }
        } catch {}
        try {
            # ensure docker redis exists; if not, try to start the container
            $c = docker ps --filter "name=med_delivery_redis" --format "{{.Names}}" 2>$null
            if (-not $c) {
                cd $backendDir
                try { docker compose up -d 2>$null } catch {}
            }
        } catch {}
        try {
            $node = Get-Process -Name "node" -ErrorAction SilentlyContinue
            if (-not $node) {
                Start-Process -FilePath "cmd.exe" -ArgumentList "/c cd /d `"$backendDir`" && npm run start:dev" -WorkingDirectory $backendDir -WindowStyle Hidden
            }
        } catch {}
        Start-Sleep -Seconds 15
    }
}

$monitorJob = Start-Job -ScriptBlock $monitorScript -ArgumentList $backendDir, $backendPort
Log "Monitor job started (ID: $($monitorJob.Id))." "Cyan"

# auto shutdown watcher (terminate node and redis when VS Code closes)
try {
    Register-WmiEvent -Query "SELECT * FROM Win32_ProcessStopTrace WHERE ProcessName='Code.exe'" -Action {
        try { Get-Process -Name "node" -ErrorAction SilentlyContinue | Stop-Process -Force } catch {}
        try { docker rm -f med_delivery_redis -v 2>$null } catch {}
    } | Out-Null
    Log "Auto-shutdown watcher active (VS Code close)." "Cyan"
} catch {
    Log "Auto-shutdown watcher skipped: $($_.Exception.Message)" "Yellow"
}

Log "✅ Backend Master Controller ready. Full automation online." "Green"
Notify "Backend Ready" "All systems operational."
